<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Script Auto Suggest Sederhana dengan jQuery - Media Kreatif</title>
<style>
fieldset{margin-bottom: 1em;width:300px;}
input{display: block;margin-bottom: .25em;}
#suggest{position:absolute;z-index:5;border-left:silver 1px solid;padding:0 0 0 10px;}
span.pilihan{display:block;cursor:pointer;}
</style>
<script src="jquery-1.7.2.min.js"></script>
<script src="prmajax.js"></script>
</head>
<body>
<form>
<fieldset>
<table>
	<tr>
		<td>Kota Kelahiran</td>
		<td><input id="src" type="text" onkeypress="suggest(this.value);" placeholder="Tulis nama kota"><div id="suggest"></div></td>
	</tr>
</table>
</fieldset>
</form>

</body>
</html>