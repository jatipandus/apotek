<?php
$con = mysql_connect('localhost','root','kutukupret');
$db  = mysql_select_db('tutorial',$con);

$src = addslashes($_POST['src']);
$query = mysql_query('select * from kota where Kota like "'.$src.'%" ');
while($data=mysql_fetch_array($query)){
	echo '<span class="pilihan" onclick="pilih_kota(\''.$data['Kota'].'\');hideStuff(\'suggest\');">'.$data['Kota'].'</span>';
}
?>