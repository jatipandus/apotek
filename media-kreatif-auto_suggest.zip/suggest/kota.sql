-- phpMyAdmin SQL Dump
-- version 4.0.5
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Aug 05, 2014 at 10:46 AM
-- Server version: 5.0.51b-community-nt-log
-- PHP Version: 5.2.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `tutorial`
--

-- --------------------------------------------------------

--
-- Table structure for table `kota`
--

CREATE TABLE IF NOT EXISTS `kota` (
  `IDKota` int(5) NOT NULL auto_increment,
  `Kota` varchar(50) NOT NULL,
  `IDProp` int(2) NOT NULL,
  PRIMARY KEY  (`IDKota`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=14 ;

--
-- Dumping data for table `kota`
--

INSERT INTO `kota` (`IDKota`, `Kota`, `IDProp`) VALUES
(1, 'Malang', 1),
(2, 'Pasuruan', 1),
(3, 'Probolinggo', 1),
(4, 'Lumajang', 1),
(5, 'Semarang', 2),
(6, 'Banyumas', 2),
(7, 'Bantul', 2),
(8, 'Banten', 3),
(9, 'Cilacap', 3),
(10, 'Cirebon', 3),
(11, 'Cikeas', 3),
(12, 'Cimanggis', 3),
(13, 'Cijeruk', 3);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
